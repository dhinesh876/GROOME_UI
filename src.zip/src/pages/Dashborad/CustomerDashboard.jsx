// // src/pages/dashboard/CustomerDashboard.jsx
// import {
//   useCallback,
//   useEffect,
//   useState,
// } from "react";
// import "../../styles/CustomerDashboard.css";
// import MyAppointments from "./MyAppointment";

// import {
//   browseShops,
//   getShopById,
// } from "../../api/shopApi";
// // import LocationSearchBar from "../Dashborad/LocationAccess";

// import BookAppointment from "./BookAppointment";

// import Profile from "./Profile";


// export default function CustomerDashboard({
//   tab,
//   setTab,
//   city
// }) {
//   const [shops, setShops] = useState([]);

//   const [loading, setLoading] =
//     useState(true);

//   const [error, setError] =
//     useState("");

//   // null = shop list
//   // object = a shop is open -> goes straight into BookAppointment
//   const [selectedShop, setSelectedShop] =
//     useState(null);

//   const [search, setSearch] =
//     useState("");


//   const user = JSON.parse(
//     localStorage.getItem("user") || "{}"
//   );

//   /*
//   ============================================
//   LOAD SHOPS
//   ============================================
//   */

//   const loadShops = useCallback(
//     async () => {
//       setLoading(true);

//       setError("");


//       try {
//         const response =
//           await browseShops(
//             user.userid,
//             city
//           );


//         setShops(
//           response.data.shops ||
//           response.data
//         );

//       } catch (err) {
//         setError(
//           err.response?.data?.message ||
//           "Could not load shops."
//         );
//       } finally {
//         setLoading(false);
//       }
//     },
//     [
//       user.userid,
//       city
//     ]
//   );

//   const today = new Date().toLocaleDateString("en-US", {
//     weekday: "short",
//   });


//   useEffect(() => {

//     if (city) {
//       loadShops();
//     }

//   }, [city, loadShops]);


//   /*
//   ============================================
//   OPEN SHOP -> straight into the booking flow
//   (BookAppointment shows the shop name/header
//   itself as its Step 1 intro, so there's no
//   separate "shop detail" screen anymore)
//   ============================================
//   */

//   const openShop = async (
//     shopId
//   ) => {
//     setError("");


//     try {
//       const response =
//         await getShopById(
//           shopId,
//           user.userid
//         );


//       setSelectedShop(
//         response.data.shop ||
//         response.data
//       );

//     } catch (err) {
//       setError(
//         err.response?.data?.message ||
//         "Could not load shop details."
//       );
//     }
//   };


//   /*
//   ============================================
//   BACK TO SHOP LIST
//   (this is what BookAppointment's own
//   "Back to results" button calls now —
//   one click, straight to the grid)
//   ============================================
//   */

//   const handleBackToResults = () => {
//     setSelectedShop(null);

//     setError("");
//   };


//   /*
//   ============================================
//   RENDER
//   ============================================
//   */

//   if (!city) {

//     return (

//       <div className="cd-noLocation">

//         <h2>Select your location</h2>

//         <p>
//           Please detect your location or enter your city to browse nearby salons.
//         </p>

//       </div>

//     );

//   } else {
//     return (
//       <>

//         {/* ======================================
//           DASHBOARD TABS
//       ======================================= */}

//         <div className="dash-tabs">

//           <button
//             className={`dash-tab ${tab === "home"
//               ? "active"
//               : ""
//               }`}
//             onClick={() => {
//               setTab("home");

//               setSelectedShop(null);

//               setError("");
//             }}
//           >
//             Browse shops
//           </button>


//           <button
//             className={`dash-tab ${tab === "appointments"
//               ? "active"
//               : ""
//               }`}
//             onClick={() => {
//               setTab("appointments");

//               setSelectedShop(null);
//             }}
//           >
//             My appointments
//           </button>


//           <button
//             className={`dash-tab ${tab === "profile"
//               ? "active"
//               : ""
//               }`}
//             onClick={() => {
//               setTab("profile");

//               setSelectedShop(null);
//             }}
//           >
//             Profile
//           </button>

//         </div>


//         <div className="dash-content">

//           {/* ====================================
//             PROFILE
//         ===================================== */}

//           {tab === "profile" && (
//             <Profile />
//           )}


//           {/* ====================================
//             HOME - SHOP LIST
//         ===================================== */}

//           {tab === "home" &&
//             !selectedShop && (
//               <>

//                 <h1 className="dash-heading">
//                   Find a shop
//                 </h1>


//                 <p className="dash-subheading">
//                   Browse nearby salons and services.
//                 </p>


//                 <div
//                   className="dash-field"
//                   style={{
//                     maxWidth: 320,
//                     marginBottom: 20,
//                   }}
//                 >
//                   <input
//                     placeholder="Search shops..."
//                     value={search}
//                     onChange={(e) =>
//                       setSearch(
//                         e.target.value
//                       )
//                     }
//                     onKeyDown={(e) => {
//                       if (
//                         e.key === "Enter"
//                       ) {
//                         loadShops();
//                       }
//                     }}
//                   />
//                 </div>


//                 {error && (
//                   <p className="auth-error">
//                     {error}
//                   </p>
//                 )}


//                 {loading ? (
//                   <p className="empty-state">
//                     Loading shops...
//                   </p>
//                 ) : shops.length === 0 ? (
//                   <p className="empty-state">
//                     No shops found yet.
//                   </p>
//                 ) : (
//                   <div className="cd-shop-grid">

//                     {/* {shops.map(
//                       (shop) => (
//                         <div
//                           key={shop._id}
//                           className="cd-shop-card"
//                           onClick={() =>
//                             openShop(
//                               shop._id
//                             )
//                           }
//                         >

//                           <div
//                             className="cd-shop-card-photo"
//                             style={
//                               shop.photo
//                                 ? {
//                                   backgroundImage:
//                                     `url(${shop.photo?.url || shop.photo})`,
//                                   backgroundSize:
//                                     "cover",
//                                   backgroundPosition:
//                                     "center",
//                                 }
//                                 : undefined
//                             }
//                           />


//                           <div className="cd-shop-card-body">

//                             <p className="cd-shop-card-name">
//                               {shop.shopname}
//                             </p>


//                             <p className="cd-shop-card-meta">
//                               {shop.address}
//                             </p>


//                             <div className="pill-row">

//                               <span className="pill">
//                                 {
//                                   shop.genderCategory
//                                 }
//                               </span>


//                               <span className="pill">
//                                 {
//                                   shop.openingTime
//                                 }
//                                 –
//                                 {
//                                   shop.closingTime
//                                 }
//                               </span>

//                             </div>

//                           </div>

//                         </div>
//                       )
//                     )} */}

//                     {shops.map((shop) => {
//                       const isOpenToday = shop.workingDays?.includes(today);

//                       return (
//                         <div
//                           key={shop._id}
//                           className={`cd-shop-card ${!isOpenToday ? "cd-shop-disabled" : ""}`}
//                           onClick={() => {
//                             if (isOpenToday) {
//                               openShop(shop._id);
//                             }
//                           }}
//                         >
//                           <div
//                             className="cd-shop-card-photo"
//                             style={
//                               shop.photo
//                                 ? {
//                                   backgroundImage: `url(${shop.photo?.url || shop.photo})`,
//                                   backgroundSize: "cover",
//                                   backgroundPosition: "center",
//                                 }
//                                 : undefined
//                             }
//                           />

//                           <div className="cd-shop-card-body">
//                             <p className="cd-shop-card-name">
//                               {shop.shopname}
//                             </p>

//                             <p className="cd-shop-card-meta">
//                               {shop.address}
//                             </p>

//                             <div className="pill-row">
//                               <span className="pill">
//                                 {shop.genderCategory}
//                               </span>

//                               <span className="pill">
//                                 {shop.openingTime} – {shop.closingTime}
//                               </span>

//                               {!isOpenToday && (
//                                 <span className="pill cd-shop-closed-pill" style={{ background: "red", color: "white" }}>
//                                   Closed Today
//                                 </span>
//                               )}
//                             </div>
//                           </div>
//                         </div>
//                       );
//                     })}

//                   </div>
//                 )}

//               </>
//             )}


//           {/* ====================================
//             SHOP OPEN -> straight into booking
//             (no separate old-design detail screen
//             anymore — BookAppointment handles the
//             whole thing, one consistent design)
//         ===================================== */}

//           {tab === "home" &&
//             selectedShop && (
//               <BookAppointment
//                 shop={selectedShop}
//                 onBack={handleBackToResults}
//                 onBooked={() => {
//                   setTab("appointments");
//                   setSelectedShop(null);
//                 }}
//               />
//             )}


//           {/* ====================================
//             APPOINTMENTS
//         ===================================== */}

//           {tab === "appointments" && (
//             <MyAppointments />
//           )}

//         </div>

//       </>
//     );
//   }
// }


//new

// src/pages/dashboard/CustomerDashboard.jsx
import {
  useCallback,
  useEffect,
  useState,
} from "react";
import "../../styles/CustomerDashboard.css";
import MyAppointments from "./MyAppointment";

import {
  browseShops,
  getShopById,
} from "../../api/shopApi";
// import LocationSearchBar from "../Dashborad/LocationAccess";

import BookAppointment from "./BookAppointment";

import Profile from "./Profile";


export default function CustomerDashboard({
  tab,
  setTab,
  city
}) {
  const [shops, setShops] = useState([]);

  const [loading, setLoading] =
    useState(true);

  const [error, setError] =
    useState("");

  // null = shop list
  // object = a shop is open -> goes straight into BookAppointment
  const [selectedShop, setSelectedShop] =
    useState(null);

  const [search, setSearch] =
    useState("");


  const user = JSON.parse(
    localStorage.getItem("user") || "{}"
  );

  /*
  ============================================
  LOAD SHOPS
  ============================================
  */

  const loadShops = useCallback(
    async () => {
      setLoading(true);

      setError("");


      try {
        const response =
          await browseShops(
            user.userid,
            city
          );


        setShops(
          response.data.shops ||
          response.data
        );

      } catch (err) {
        setError(
          err.response?.data?.message ||
          "Could not load shops."
        );
      } finally {
        setLoading(false);
      }
    },
    [
      user.userid,
      city
    ]
  );

  const today = new Date().toLocaleDateString("en-US", {
    weekday: "short",
  });


  useEffect(() => {

    if (city) {
      loadShops();
    }

  }, [city, loadShops]);


  /*
  ============================================
  OPEN SHOP -> straight into the booking flow
  (BookAppointment shows the shop name/header
  itself as its Step 1 intro, so there's no
  separate "shop detail" screen anymore)
  ============================================
  */

  const openShop = async (
    shopId
  ) => {
    setError("");


    try {
      const response =
        await getShopById(
          shopId,
          user.userid
        );


      setSelectedShop(
        response.data.shop ||
        response.data
      );

    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Could not load shop details."
      );
    }
  };


  /*
  ============================================
  BACK TO SHOP LIST
  (this is what BookAppointment's own
  "Back to results" button calls now —
  one click, straight to the grid)
  ============================================
  */

  const handleBackToResults = () => {
    setSelectedShop(null);

    setError("");
  };


  /*
  ============================================
  RENDER
  ============================================
  */

  if (!city) {

    return (

      <div className="cd-noLocation">

        <h2>Select your location</h2>

        <p>
          Please detect your location or enter your city to browse nearby salons.
        </p>

      </div>

    );

  } else {
    return (
      <>

        {/* ======================================
          DASHBOARD TABS
      ======================================= */}

        <div className="dash-tabs">

          <button
            className={`dash-tab ${tab === "home"
              ? "active"
              : ""
              }`}
            onClick={() => {
              setTab("home");

              setSelectedShop(null);

              setError("");
            }}
          >
            Browse shops
          </button>


          <button
            className={`dash-tab ${tab === "appointments"
              ? "active"
              : ""
              }`}
            onClick={() => {
              setTab("appointments");

              setSelectedShop(null);
            }}
          >
            My appointments
          </button>


          <button
            className={`dash-tab ${tab === "profile"
              ? "active"
              : ""
              }`}
            onClick={() => {
              setTab("profile");

              setSelectedShop(null);
            }}
          >
            Profile
          </button>

        </div>


        <div className="dash-content">

          {/* ====================================
            PROFILE
        ===================================== */}

          {tab === "profile" && (
            <Profile />
          )}


          {/* ====================================
            HOME - SHOP LIST
        ===================================== */}

          {tab === "home" &&
            !selectedShop && (
              <>

                <h1 className="dash-heading">
                  Find a shop
                </h1>


                <p className="dash-subheading">
                  Browse nearby salons and services.
                </p>


                <div
                  className="dash-field"
                  style={{
                    maxWidth: 320,
                    marginBottom: 20,
                  }}
                >
                  <input
                    placeholder="Search shops..."
                    value={search}
                    onChange={(e) =>
                      setSearch(
                        e.target.value
                      )
                    }
                    onKeyDown={(e) => {
                      if (
                        e.key === "Enter"
                      ) {
                        loadShops();
                      }
                    }}
                  />
                </div>


                {error && (
                  <p className="auth-error">
                    {error}
                  </p>
                )}


                {loading ? (
                  <p className="empty-state">
                    Loading shops...
                  </p>
                ) : shops.length === 0 ? (
                  <p className="empty-state">
                    No shops found yet.
                  </p>
                ) : (
                  <div className="cd-shop-grid">

                    {/* {shops.map(
                      (shop) => (
                        <div
                          key={shop._id}
                          className="cd-shop-card"
                          onClick={() =>
                            openShop(
                              shop._id
                            )
                          }
                        >
 
                          <div
                            className="cd-shop-card-photo"
                            style={
                              shop.photo
                                ? {
                                  backgroundImage:
                                    `url(${shop.photo?.url || shop.photo})`,
                                  backgroundSize:
                                    "cover",
                                  backgroundPosition:
                                    "center",
                                }
                                : undefined
                            }
                          />
 
 
                          <div className="cd-shop-card-body">
 
                            <p className="cd-shop-card-name">
                              {shop.shopname}
                            </p>
 
 
                            <p className="cd-shop-card-meta">
                              {shop.address}
                            </p>
 
 
                            <div className="pill-row">
 
                              <span className="pill">
                                {
                                  shop.genderCategory
                                }
                              </span>
 
 
                              <span className="pill">
                                {
                                  shop.openingTime
                                }
                                –
                                {
                                  shop.closingTime
                                }
                              </span>
 
                            </div>
 
                          </div>
 
                        </div>
                      )
                    )} */}

                    {shops.map((shop) => {
                      const isOpenToday = shop.workingDays?.includes(today);

                      return (
                        <div
                          key={shop._id}
                          className={`cd-shop-card ${!isOpenToday ? "cd-shop-disabled" : ""}`}
                          onClick={() => {
                            if (isOpenToday) {
                              openShop(shop._id);
                            }
                          }}
                        >
                          <div
                            className="cd-shop-card-photo"
                            style={
                              shop.photo
                                ? {
                                  backgroundImage: `url(${shop.photo?.url || shop.photo})`,
                                  backgroundSize: "cover",
                                  backgroundPosition: "center",
                                }
                                : undefined
                            }
                          />

                          <div className="cd-shop-card-body">
                            <p className="cd-shop-card-name">
                              {shop.shopname}
                            </p>

                            <p className="cd-shop-card-meta">
                              {shop.address}
                            </p>

                            <div className="pill-row">
                              <span className="pill">
                                {shop.genderCategory}
                              </span>

                              <span className="pill">
                                {shop.openingTime} – {shop.closingTime}
                              </span>

                              {!isOpenToday && (
                                <span className="pill cd-shop-closed-pill">
                                  Closed Today
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}

                  </div>
                )}

              </>
            )}


          {/* ====================================
            SHOP OPEN -> straight into booking
            (no separate old-design detail screen
            anymore — BookAppointment handles the
            whole thing, one consistent design)
        ===================================== */}

          {tab === "home" &&
            selectedShop && (
              <BookAppointment
                shop={selectedShop}
                onBack={handleBackToResults}
                onBooked={() => {
                  setTab("appointments");
                  setSelectedShop(null);
                }}
              />
            )}


          {/* ====================================
            APPOINTMENTS
        ===================================== */}

          {tab === "appointments" && (
            <MyAppointments />
          )}

        </div>

      </>
    );
  }
}
